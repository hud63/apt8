---
name: illumend-brand
description: >
  Pixel-perfect illumend/myCOI branded document generation. Use when creating 
  PowerPoint presentations (.pptx), documents, or any visual content that must 
  match the official illumend brand template. Triggers include illumend presentations, 
  illumend template, myCOI branded docs, CX playbooks, compliance presentations, 
  or when user references the illumend brand style. Ensures exact color codes, 
  typography, layouts, and logo placement matching the official brand guidelines.
---

# illumend Brand Template

Generate pixel-perfect illumend-branded presentations and documents.

## Quick Reference

### Colors
- **Background**: Black `#000000`
- **Primary text**: White `#FFFFFF`
- **Secondary text**: Gray `#ADADAD`
- **Accent orange**: `#FFAB40`
- **Accent teal**: `#009688`
- **Accent cyan**: `#4DD0E1`

### Fonts (Google Fonts)
- **Figtree** (Bold): Covers, section headers
- **Manrope**: Titles, body text

### Key Sizes
- Cover title: 56pt Figtree Bold
- Section header: 96pt Figtree Bold
- Slide title: 36pt Manrope (gray)
- Body text: 20pt (white)

## Workflow

### For PowerPoint Presentations

1. **Read the pptx skill** first: `view /mnt/skills/public/pptx/SKILL.md`
2. **Read the full design spec**: `view` the `references/design-specification.md` file in this skill
3. **Use the brand assets** from `assets/` directory:
   - `illumend-logo-vertical.png` - For slide headers
   - `illumend-logo-horizontal.png` - For footers
   - `section-divider-gradient.png` - Section divider background

### Slide Structure Requirements

#### Cover Slide
```
┌─────────────────────────────────┐
│                      [LOGO]     │
│                                 │
│              Title Text         │  ← Figtree Bold 56pt, right-aligned, white
│              (right-aligned)    │
│                                 │
│           Compliance Made Easy  │  ← Figtree 20pt, bottom right
└─────────────────────────────────┘
Background: Dark gradient or black
```

#### Section Divider Slide
```
┌─────────────────────────────────┐
│                      [LOGO]     │
│                                 │
│  SECTION TITLE                  │  ← Figtree Bold 96pt, white
│                                 │
│                                 │
│  Compliance Made Easy    Conf.  │
└─────────────────────────────────┘
Background: section-divider-gradient.png (coral→purple→blue)
```

#### Content Slide
```
┌─────────────────────────────────┐
│                                 │
│  Slide Title                    │  ← Manrope 36pt, gray #ADADAD
│                                 │
│  • Bullet point text            │  ← 20pt white, 115% line spacing
│  • Another bullet point         │    Bullet: filled circle ●
│  • Third point                  │
│                                 │
└─────────────────────────────────┘
Background: Pure black #000000
```

## HTML/CSS Implementation

When creating HTML artifacts or web content:

```css
/* illumend Brand Styles */
body {
  background: #000000;
  color: #FFFFFF;
  font-family: 'Manrope', sans-serif;
}

h1, .section-title {
  font-family: 'Figtree', sans-serif;
  font-weight: 700;
  font-size: 96pt;
  line-height: 0.8;
}

h2, .slide-title {
  font-family: 'Manrope', sans-serif;
  font-size: 36pt;
  color: #ADADAD;
}

.body-text {
  font-size: 20pt;
  line-height: 1.15;
}

.section-divider {
  background: linear-gradient(135deg, #E55A50 0%, #7B3FA0 50%, #4A7CB5 100%);
}
```

## Validation Checklist

Before delivering, verify:
- [ ] Background is pure black `#000000` (not dark gray)
- [ ] Text is white `#FFFFFF` or gray `#ADADAD`
- [ ] Figtree used for display text (covers, sections)
- [ ] Manrope used for body content
- [ ] Logo positioned upper right
- [ ] "Compliance Made Easy" tagline in footer
- [ ] Section dividers use gradient background
- [ ] Line spacing at 115% for body text
- [ ] Bullet points use filled circles ●

## Font Installation

Include Google Fonts import:
```html
<link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;700&family=Manrope:wght@400;700&display=swap" rel="stylesheet">
```
