# illumend Design Specification

## Presentation Dimensions
- **Size**: 18,288,000 × 10,287,000 EMUs (16:9 widescreen, 1920×1080 equivalent)
- **Aspect Ratio**: 16:9

## Color Palette

### Theme Colors (Simple Dark)
| Role | Hex | Usage |
|------|-----|-------|
| dk1 | `#FFFFFF` | Primary text (white) |
| lt1 | `#212121` | Primary dark background |
| dk2 | `#303030` | Secondary dark |
| lt2 | `#ADADAD` | Muted text (gray) |
| accent1 | `#009688` | Teal accent |
| accent2 | `#EEEEEE` | Light gray |
| accent3 | `#78909C` | Blue-gray |
| accent4 | `#FFAB40` | Orange/amber |
| accent5 | `#4DD0E1` | Cyan/aqua |
| accent6 | `#EEFF41` | Yellow |

### Primary Background
- **Content slides**: Pure black `#000000`
- **Section dividers**: Coral→Purple→Blue gradient (use `section-divider-gradient.png`)

## Typography

### Font Families
| Font | Usage |
|------|-------|
| **Figtree** | Cover titles, section headers |
| **Manrope** | Slide titles, body text |
| **Inter Tight** | Master defaults |

### Font Sizes
| Element | Size | Font | Weight | Color |
|---------|------|------|--------|-------|
| Cover Title | 56pt | Figtree | Bold | white (#FFFFFF) |
| Section Title | 96pt | Figtree | Bold | white (#FFFFFF) |
| Slide Title | 36pt | Manrope | Regular | gray (#ADADAD) |
| Body Text | 20pt | default | Regular | white (#FFFFFF) |
| Tagline | 20pt | Figtree | Regular | white (#FFFFFF) |

### Text Formatting
- **Line spacing body**: 115%
- **Line spacing titles**: 80%
- **Bullet character**: Filled circle ● (Unicode 9679)
- **Bullet indent**: -355600 EMUs hanging, 457200 EMUs margin

## Layout

### Margins
- **Left/Right**: ~0.92 inches (837,825–921,575 EMUs)
- **Top (titles)**: ~0.97–1.33 inches

### Logo Placement
- **Cover slides**: Upper right, x=14358800, y=2987150, size 3007627×1197150
- **Section dividers**: Upper right, x=15310825, y=1388450, size 2055600×818206

### Footer Elements
- **"Compliance Made Easy"**: Bottom left
- **"Confidential"**: Bottom right
- **Slide number**: Far bottom right, right-aligned

## Slide Types

### 1. Cover/Title Slide
- Full-bleed gradient or dark background
- Logo upper right
- Title: Figtree Bold 56pt, right-aligned
- Tagline bottom right

### 2. Section Divider
- Gradient background (coral→purple→blue)
- Title: Figtree Bold 96pt, left-aligned, vertically centered
- Logo upper right corner
- Footer: tagline left, "Confidential" right

### 3. Content Slide
- Black background (#000000)
- Title: Manrope 36pt, gray (#ADADAD)
- Body: 20pt white with 115% line spacing
- Bullets: filled circles

## CSS Variables for HTML Recreation

```css
:root {
  --color-white: #FFFFFF;
  --color-black: #000000;
  --color-gray: #ADADAD;
  --color-dark-bg: #212121;
  --color-accent-teal: #009688;
  --color-accent-orange: #FFAB40;
  --color-accent-cyan: #4DD0E1;
  
  --font-display: 'Figtree', sans-serif;
  --font-body: 'Manrope', sans-serif;
  
  --text-cover: 56pt;
  --text-section: 96pt;
  --text-title: 36pt;
  --text-body: 20pt;
  
  --line-height-body: 1.15;
  --line-height-title: 0.8;
}
```

## Brand Assets

Located in `assets/` directory:
- `illumend-logo-vertical.png` - Stacked logo for headers
- `illumend-logo-horizontal.png` - Single-line logo variant
- `section-divider-gradient.png` - Background for section slides
