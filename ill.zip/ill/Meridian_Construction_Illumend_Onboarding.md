# Welcome to Illumend, Meridian Construction Group

**Your Path to Effortless Subcontractor Compliance**

*Prepared for Sarah Chen (CFO) and Marcus Williams (Director of Risk & Compliance)*  
*January 2026*

---

## Your 90-Day Success Goals

Based on our discovery call, here's what success looks like for Meridian:

| Goal | Metric | Target |
|------|--------|--------|
| **Reclaim Team Time** | Hours spent on COI management | 50% reduction |
| **Eliminate Coverage Gaps** | Subs working with lapsed coverage | Zero incidents |
| **Real-Time Visibility** | Compliance status dashboard | Available 24/7 |
| **Executive Reporting** | Monthly risk posture reports | Automated delivery |

---

## Getting Started: Your First Week with Illumend

### Day 1: Account Setup & Team Access

**Step 1: Configure Your Organization**  
Log in to your Illumend dashboard. Lumie, your AI compliance assistant, will guide you through initial setup. Start by confirming your company profile and primary contact information.

**Step 2: Set Up User Roles**  
Add your team with the right permissions:

| Team Member | Role | Access Level |
|-------------|------|--------------|
| Marcus Williams | Admin | Full configuration, approvals, reporting |
| Compliance Coordinators (2) | Compliance Manager | Certificate review, requirement management |
| Project Managers | Viewer | Status visibility, no editing |
| Finance Team | Reporter | Dashboard access, report generation |

**Step 3: Connect Procore**  
Navigate to Integrations → Procore. Authorize the connection using your Procore admin credentials. Once connected, new subcontractors added to any Procore project will automatically trigger compliance requests through Illumend.

---

### Day 2-3: Configure Your Insurance Requirements

**Your Tiered Requirement Structure**

Based on your current process, we recommend setting up three requirement tiers:

**Tier 1: Standard Subcontractors** (Contracts under $50K)
- General Liability: $1M per occurrence / $2M aggregate
- Workers' Compensation: Statutory limits
- Auto Liability: $1M combined single limit
- Additional Insured endorsement required

**Tier 2: Mid-Value Subcontractors** (Contracts $50K - $250K)
- All Tier 1 requirements, plus:
- Umbrella/Excess: $2M

**Tier 3: High-Value & High-Risk Trades** (Contracts over $250K or roofing, electrical, hazmat)
- All Tier 1 requirements, plus:
- Umbrella/Excess: $5M
- Professional Liability: $1M (for design-build)

**Setting Up Owner Flow-Down Requirements**

For clients like Vertex Development with specific insurance requirements:
1. Go to Settings → Requirement Templates
2. Create a custom template named "Vertex Development Projects"
3. Enter Vertex's specific coverage requirements
4. Apply this template to any project where Vertex is the owner

Lumie will automatically apply the correct requirements based on project assignment.

---

### Day 4-5: Import Your Subcontractor Database

**Bulk Import Your 350+ Subcontractors**

1. Export your current subcontractor list from your spreadsheet
2. Use our import template (download from Settings → Data Import)
3. Required fields: Company Name, Primary Contact Email, Trade Category
4. Optional but recommended: Contract Value Tier, Current COI Expiration Date

**What Happens Next**

Once imported, Lumie automatically:
- Sends personalized compliance requests to each subcontractor
- Explains exactly what documents they need in plain language
- Provides a simple upload link (no login required for subs)
- Tracks responses and sends follow-ups

Your subcontractors receive a message like this:

> *"Hi [Sub Name], Meridian Construction Group needs your current certificate of insurance. You'll need to show: General Liability at $1M/$2M, Workers' Comp, and Auto Liability. Click here to upload—it takes less than 2 minutes."*

---

## Features Built for Your Workflow

### Lumie: Your AI Compliance Partner

Lumie isn't just software—it's like adding an insurance expert to your team who works 24/7.

**For Marcus and the Compliance Team:**
- Upload a contract and Lumie extracts insurance requirements automatically
- Ask questions in plain English: *"Which subs are more than 30 days non-compliant?"*
- Lumie verifies certificates in seconds, not the 15-20 minutes manual review takes
- Get instant alerts only when action is required

**For Sarah and the Finance Team:**
- One-click compliance snapshots for board meetings
- Risk exposure summaries showing your biggest gaps
- Audit-ready documentation generated automatically
- Monthly trend reports delivered to your inbox

---

### Renewals on Autopilot

Remember chasing subs for weeks before renewals? That's over.

**How It Works:**
1. Lumie tracks every policy expiration date
2. 60 days before expiration: Automated reminder to subcontractor
3. 30 days before: Follow-up with escalation
4. 14 days before: Alert to your team if no response
5. Day of expiration: Compliance status changes to "At Risk"

**Your Project Managers See This:**

When viewing a subcontractor in Illumend or Procore, PMs see a simple status:
- 🟢 **Compliant** — Clear to work
- 🟡 **Expiring Soon** — Coverage expires within 30 days
- 🔴 **Non-Compliant** — Do not authorize work

No more subs on site with lapsed coverage.

---

### Risk Insights Dashboard

The visibility Sarah asked for—always available, always current.

**Your Executive Dashboard Shows:**
- Total subcontractors: 350
- Currently compliant: [Live percentage]
- Expiring within 30 days: [Count]
- Non-compliant requiring action: [Count]
- Estimated risk exposure: [Dollar amount based on gap analysis]

**Drill Down By:**
- Trade category (roofing, electrical, HVAC, etc.)
- Contract value tier
- Project assignment
- Compliance history

---

## Best Practices for Construction COI Management

### Workflow 1: New Subcontractor Onboarding

**Before (Your Old Process):**
1. PM adds sub to project
2. Email sent manually requesting COI
3. Wait for response (days to weeks)
4. Manually review certificate
5. Log in spreadsheet
6. Set calendar reminder
7. Hope nobody forgets

**After (With Illumend + Procore):**
1. PM adds sub to project in Procore
2. Illumend automatically requests COI with correct requirements
3. Sub uploads directly (no email attachments)
4. Lumie verifies instantly
5. PM sees green status in Procore
6. Done.

**Time Saved:** 15-20 minutes per subcontractor

---

### Workflow 2: Handling Non-Compliance

When Lumie identifies a coverage gap:

1. **Lumie explains the issue in plain language**  
   *"ABC Roofing's General Liability shows $500K per occurrence. Your requirement is $1M. They need to increase coverage or provide an umbrella policy."*

2. **Automatic notification to subcontractor**  
   Sub receives clear instructions on exactly what needs to change

3. **Broker can update directly**  
   Subs can share the request with their insurance broker, who can upload corrected COI

4. **Your team only intervenes for exceptions**  
   Most issues resolve without your involvement

---

### Workflow 3: Owner Flow-Down Requirements

For projects with clients like Vertex Development:

1. Create project in Procore with Vertex as owner
2. In Illumend, assign the "Vertex Development" requirement template
3. All subs on that project automatically receive Vertex-specific requirements
4. Lumie tracks against enhanced requirements
5. Generate Vertex-specific compliance reports with one click

---

## Your 90-Day Roadmap

### Week 1: Foundation
- [ ] Complete account setup and user provisioning
- [ ] Connect Procore integration
- [ ] Configure three-tier requirement templates
- [ ] Import subcontractor database
- [ ] Send first batch of compliance requests

### Weeks 2-4: Adoption
- [ ] Train compliance team on Lumie features
- [ ] Train project managers on status visibility
- [ ] Process first wave of certificate submissions
- [ ] Configure automated renewal reminders
- [ ] Set up executive dashboard for Sarah

### Weeks 5-8: Optimization
- [ ] Review compliance metrics and adjust workflows
- [ ] Create owner-specific templates (Vertex, others)
- [ ] Establish escalation procedures for persistent non-compliance
- [ ] Generate first monthly board report

### Weeks 9-12: Mastery
- [ ] Measure time savings vs. baseline
- [ ] Document zero-gap compliance achievement
- [ ] Share success metrics with leadership
- [ ] Plan for expanded use cases

---

## Recommended Next Actions

### This Week

1. **Schedule Kickoff Session**  
   Your Customer Success Manager will walk through setup live. Bring Marcus and one compliance coordinator.

2. **Prepare Your Subcontractor Export**  
   Pull your current sub list with emails. We'll help you format it for import.

3. **Gather Procore Admin Credentials**  
   You'll need these to authorize the integration.

4. **Document Vertex Requirements**  
   Have a copy of Vertex Development's insurance requirements ready for template setup.

### Questions? Lumie Is Here

Once you're in the platform, just ask Lumie anything:
- *"How do I set up a custom requirement template?"*
- *"Show me all subs with expiring coverage this month"*
- *"Generate a compliance report for the Riverside Project"*

Lumie responds in seconds with clear, actionable answers.

---

## Your Illumend Team

**Customer Success Manager:** Ashley Torres  
- Email: ashley.torres@illumend.ai
- Direct line for onboarding questions

**Technical Support:** Available 24/7  
- In-app chat with Lumie for instant answers
- support@illumend.ai for complex issues

**60-Day Guarantee**  
Try Illumend risk-free. If you're not seeing the time savings and visibility we promised, you get a full refund—no questions asked.

---

## Gamma.ai Styling Notes

**Brand Colors:**
- Primary Purple: #801FB3
- Dark Accent: #220335
- Background Cream: #FFFAF2
- Text: #220335

**Typography:**
- Font Family: Figtree (Google Fonts) or sans-serif fallback
- Headings: Bold weight
- Body: Regular weight

**Logo:**
https://cdn.prod.website-files.com/68cd20f1535cef7be0b4fb34/68d709383da8fe112e03dc1d_logo-round.svg

**Suggested Gamma Prompt:**
"Create a professional, warm onboarding presentation using purple (#801FB3) as the primary accent color with a cream (#FFFAF2) background. Use Figtree font. Include icons for each section. Make it feel approachable and modern, not corporate or stiff. Add subtle gradients and rounded corners."

---

*From headaches to high fives. Welcome to insurance compliance that finally works for you.*
