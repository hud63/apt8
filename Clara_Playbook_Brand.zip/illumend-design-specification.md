# illumend CX Playbooks Design Specification

## Complete Design System for Pixel-Perfect Recreation

---

## 1. PRESENTATION DIMENSIONS

| Property | Value | Notes |
|----------|-------|-------|
| **Width** | 18,288,000 EMUs (20 inches / 1920px at 96dpi) | 16:9 widescreen |
| **Height** | 10,287,000 EMUs (11.25 inches / 1080px at 96dpi) | |
| **Aspect Ratio** | 16:9 | Standard widescreen |
| **Resolution** | 1920 × 1080 px equivalent | |

---

## 2. COLOR PALETTE

### 2.1 Theme Color Scheme (Simple Dark)

| Role | Hex Code | RGB | Usage |
|------|----------|-----|-------|
| **Dark 1 (dk1)** | `#FFFFFF` | 255, 255, 255 | Primary text on dark backgrounds |
| **Light 1 (lt1)** | `#212121` | 33, 33, 33 | Primary dark backgrounds |
| **Dark 2 (dk2)** | `#303030` | 48, 48, 48 | Secondary dark elements |
| **Light 2 (lt2)** | `#ADADAD` | 173, 173, 173 | Muted/secondary text (gray) |
| **Accent 1** | `#009688` | 0, 150, 136 | Teal accent |
| **Accent 2** | `#EEEEEE` | 238, 238, 238 | Light gray accent |
| **Accent 3** | `#78909C` | 120, 144, 156 | Blue-gray accent |
| **Accent 4** | `#FFAB40` | 255, 171, 64 | Orange/amber accent |
| **Accent 5** | `#4DD0E1` | 77, 208, 225 | Cyan/aqua accent |
| **Accent 6** | `#EEFF41` | 238, 255, 65 | Yellow accent |
| **Hyperlink** | `#4DD0E1` | 77, 208, 225 | Cyan |
| **Master Background** | `#000000` | 0, 0, 0 | Pure black base |

### 2.2 Gradient Specifications

#### Section Divider Background Gradient
Multi-stop radial/diagonal gradient:
- **Top-left corner**: Coral/Orange `~#E55A50` → `#D94F6D`
- **Center**: Deep Purple `~#7B3FA0` → `#6B4C9A`
- **Bottom**: Blue/Teal `~#4A7CB5` → `#5B9FD0`
- **Has subtle glow effects and light particles**

#### Card/Panel Backgrounds
- Semi-transparent dark panels with gradient border glow
- Border color: Orange/coral gradient outline
- Background: Dark purple/black with ~80% opacity

---

## 3. TYPOGRAPHY

### 3.1 Font Families

| Font Name | Usage | Notes |
|-----------|-------|-------|
| **Figtree** | Section titles, cover text, taglines | Display/heading font (embedded) |
| **Figtree Medium** | Alternate display weight | Medium weight variant |
| **Manrope** | Slide titles, body text | Primary body font (embedded) |
| **Inter Tight** | Master slide defaults | Secondary body font (embedded) |
| **Arial** | Fallback/default | System fallback |

### 3.2 Font Sizes by Element

| Element | Size (pts) | Size (EMUs) | Font | Weight | Color |
|---------|------------|-------------|------|--------|-------|
| **Cover Title** | 56pt | sz="5600" | Figtree | Bold | dk1 (white) |
| **Section Divider Title** | 96pt | sz="9600" | Figtree | Bold | dk1 (white) |
| **Slide Title** | 36pt | sz="3600" | Manrope | Regular | lt2 (gray) |
| **Body Text** | 20pt | sz="2000" | - | Regular | dk1 (white) |
| **Tagline** | 20pt | sz="2000" | Figtree | Regular | dk1 (white) |
| **Master Title Default** | 50pt | sz="5000" | Inter Tight | Regular | dk1 |
| **Default Text** | 14pt | sz="1400" | Arial | Regular | #000000 |

### 3.3 Text Formatting Rules

#### Line Spacing
- **Standard body**: 115% (`spcPct val="115000"`)
- **Section titles**: 80% (`spcPct val="80000"`)

#### Paragraph Spacing
- **Space before section headers**: 12pt (`spcPts val="1200"`)
- **Space after**: 0pt (tight)

#### Bullet Points
- **Character**: Filled circle (●) `&#9679;`
- **Size**: Same as text (2000 = 20pt)
- **Indent**: -355600 EMUs (hanging indent)
- **Margin left**: 457200 EMUs
- **Color**: dk1 (white)

---

## 4. LAYOUT SPECIFICATIONS

### 4.1 Content Margins

| Property | Value (EMUs) | Value (inches) |
|----------|--------------|----------------|
| **Left margin** | ~837,825 - 921,575 | ~0.92" |
| **Right margin** | ~921,575 | ~0.92" |
| **Top margin (titles)** | ~890,050 - 1,213,525 | ~0.97-1.33" |
| **Bottom margin** | Variable | ~1.0" |

### 4.2 Text Box Dimensions

| Element | Position (EMUs) | Size (EMUs) |
|---------|-----------------|-------------|
| **Title placeholder** | off x="623400" y="890050" | cx="17041200" cy="1145400" |
| **Body placeholder** | off x="623400" y="2304950" | cx="17041200" cy="6832800" |
| **Slide number** | off x="16269050" y="9424593" | cx="1097400" cy="184800" |

### 4.3 Logo Placements

#### Cover/Title Slides
- **Position**: Upper right area
- **Offset**: x="14358800" y="2987150"
- **Size**: cx="3007627" cy="1197150"

#### Section Divider Slides
- **Position**: Upper right corner
- **Offset**: x="15310825" y="1388450"
- **Size**: cx="2055600" cy="818206"

#### Footer Elements
- **Tagline position**: Bottom left, x="921575" y="8433950"
- **Confidential marker**: Bottom right, x="15310825" y="8433950"
- **Slide number**: Bottom right, x="16269050" y="9424593" (right-aligned)

---

## 5. SLIDE TYPE TEMPLATES

### 5.1 Cover/Title Slide
- **Background**: Full-bleed gradient image or dark solid
- **Logo**: Upper right
- **Main title**: Large Figtree Bold 56pt, right-aligned
- **Tagline**: "Compliance Made Easy" - Figtree 20pt, bottom right
- **Slide number**: Hidden or bottom right

### 5.2 Section Divider Slide
- **Background**: Vibrant orange-purple-blue gradient (image11.png style)
- **Section title**: Figtree Bold 96pt, left-aligned, vertically centered
- **Logo**: Upper right corner
- **Tagline**: "Compliance Made Easy" - bottom left
- **Confidential marker**: Bottom right
- **Line spacing**: 80%

### 5.3 Content Slide (Standard)
- **Background**: Pure black (#000000)
- **Slide title**: Manrope 36pt, lt2 color (gray), left-aligned
- **Body text**: 20pt, dk1 color (white)
- **Bullet style**: Filled circle (●)
- **Line spacing**: 115%

### 5.4 Table/Data Slide
- **Background**: Pure black
- **Table headers**: Bold, possibly with accent color
- **Table borders**: Minimal/subtle
- **Cell padding**: Standard

### 5.5 Visual/Graphic Slide
- **Often full-bleed images**
- **Card-style containers with gradient borders**
- **Icon accent colors: Orange, teal**

---

## 6. BRAND ELEMENTS

### 6.1 Logo Specifications

#### Primary Logo (Vertical Stack)
- **File**: illumend-logo-vertical.png
- **Dimensions**: 1932 × 769 px
- **Content**: "illumend" in script + "powered by myCOI" below
- **Color**: Cream/off-white (#FDF8F4 approximate)

#### Secondary Logo (Horizontal)
- **File**: illumend-logo-horizontal.png
- **Dimensions**: 1871 × 208 px
- **Content**: "illumend powered by myCOI" single line
- **Color**: Cream/off-white

### 6.2 Visual Elements

#### Decorative Elements
- **Curved accent lines**: Orange/coral ribbons/swirls
- **Light particles**: Small glowing dots throughout gradients
- **Glassmorphism panels**: Semi-transparent dark cards with gradient borders

#### Icon Style
- **Line style**: Thin outlined icons
- **Color**: Orange/coral accent or white
- **Background**: Dark rounded rectangles with gradient glow

---

## 7. CSS DESIGN SYSTEM VARIABLES

For HTML/CSS recreation, use these variables:

```css
:root {
  /* Primary Colors */
  --color-dark-1: #FFFFFF;
  --color-light-1: #212121;
  --color-dark-2: #303030;
  --color-light-2: #ADADAD;
  
  /* Accent Colors */
  --color-accent-teal: #009688;
  --color-accent-gray: #EEEEEE;
  --color-accent-blue-gray: #78909C;
  --color-accent-orange: #FFAB40;
  --color-accent-cyan: #4DD0E1;
  --color-accent-yellow: #EEFF41;
  
  /* Backgrounds */
  --bg-primary: #000000;
  --bg-gradient-start: #E55A50;
  --bg-gradient-mid: #7B3FA0;
  --bg-gradient-end: #4A7CB5;
  
  /* Typography */
  --font-display: 'Figtree', sans-serif;
  --font-body: 'Manrope', sans-serif;
  --font-system: 'Inter Tight', 'Arial', sans-serif;
  
  /* Font Sizes */
  --text-cover-title: 56pt;
  --text-section-title: 96pt;
  --text-slide-title: 36pt;
  --text-body: 20pt;
  --text-tagline: 20pt;
  
  /* Spacing */
  --margin-slide: 0.92in;
  --line-height-body: 1.15;
  --line-height-title: 0.8;
  --space-before-section: 12pt;
  
  /* Effects */
  --card-border-radius: 16px;
  --card-glow-color: rgba(255, 171, 64, 0.3);
}
```

---

## 8. EMBEDDED FONTS

The following fonts are embedded in the presentation and should be installed for accurate recreation:

1. **Figtree** (Regular, Bold, Italic, Bold Italic)
2. **Figtree Medium** (Regular, Bold, Italic, Bold Italic)
3. **Manrope** (Regular, Bold)
4. **Inter Tight** (Regular, Bold, Italic, Bold Italic)

### Font Sources
- Figtree: Google Fonts (https://fonts.google.com/specimen/Figtree)
- Manrope: Google Fonts (https://fonts.google.com/specimen/Manrope)
- Inter Tight: Google Fonts (https://fonts.google.com/specimen/Inter+Tight)

---

## 9. RECREATION CHECKLIST

### Essential Elements
- [ ] Black background (#000000) for content slides
- [ ] Gradient background for section dividers (use image11.png as reference)
- [ ] Figtree Bold for cover titles and section headers
- [ ] Manrope for body text and slide titles
- [ ] White text (#FFFFFF) on dark backgrounds
- [ ] Gray text (#ADADAD) for slide titles
- [ ] Filled circle bullets (●)
- [ ] 16:9 aspect ratio (1920×1080 or equivalent)
- [ ] illumend logo in upper right for branded slides
- [ ] "Compliance Made Easy" tagline in footer
- [ ] "Confidential" marker in bottom right corner
- [ ] Right-aligned slide numbers

### Design Quality Checks
- [ ] Line spacing at 115% for body text
- [ ] Consistent margins (~0.92 inches)
- [ ] Logo properly sized and positioned
- [ ] Gradient transitions smooth (no banding)
- [ ] Text hierarchy clear (title → subtitle → body)
- [ ] Accent colors used sparingly (orange, teal, cyan)

---

## 10. FILE ASSETS EXTRACTED

The following assets have been extracted from the original presentation:

| File | Description | Use |
|------|-------------|-----|
| `illumend-logo-vertical.png` | Vertical stacked logo | Cover slides, section headers |
| `illumend-logo-horizontal.png` | Horizontal logo variant | Footer or header strips |
| `section-divider-gradient.png` | Gradient background | Section divider backgrounds |

---

*Document generated from analysis of: Copy_of_illumend_CX_Playbooks-_Defining_the_Customer_Journey_.pptx*
